<?php

class Login extends MY_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->library('session');
		 $this->load->helper('url');
	}

	function index()
	{
		echo 'test';
		
		$data = array('id'=>'12',
					'name'=>'richa');
		$this->session->set_userdata('admin_login',$data);

		 redirect('admin/Login/testing');
	}

	public function testing()
	{
		$aa = $this->session->userdata('admin_login');
		print_r($aa);
	}
}